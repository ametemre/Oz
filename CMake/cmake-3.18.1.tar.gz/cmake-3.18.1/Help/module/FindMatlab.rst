.. cmake-module:: ../../Modules/FindMatlab.cmake

.. cmake-module:: ../../Modules/FindDoxygen.cmake

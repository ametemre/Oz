.. cmake-module:: ../../Modules/CheckCSourceCompiles.cmake
